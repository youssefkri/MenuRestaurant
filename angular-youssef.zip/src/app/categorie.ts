import { Product } from './product';

export class Categorie {
  name: string;
  products: Product[];
}