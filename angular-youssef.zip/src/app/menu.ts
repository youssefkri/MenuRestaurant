import { Categorie } from './categorie'

export class Menu {
  categories: Categorie[];
}