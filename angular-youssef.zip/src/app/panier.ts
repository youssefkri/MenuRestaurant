import { Element } from './element'

export class Panier {
  elements: Map<number,Element>=new Map;
}