export class Element {
  id: number;
  name: string;
  quantite: number;
}